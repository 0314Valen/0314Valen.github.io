<?php
    class Sqlite extends SQLite3
    {
       function __construct()
       {
            $this->db_file = "sqlite.db";
       }
        public function select($sql)
        {
            try {
                $maindir = $this->db_file;
                $main = new \SQLite3($maindir);
                if (!$main) {
                    echo 'code：' . $main->lastErrorCode();
                    echo 'Error：' . $main->lastErrorMsg();
                    $main->close();
                    die;
                }
                $result = $main->query($sql);
                $ret = [];
                while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
                    $ret[] = $row;
                }
                $main->close();
            } catch (\Exception $e) {
                if (isset($main)) {
                    $main->close();
                }
                var_dump($e->getMessage());
            }
            return $ret;
        }

        public function query($sql)
        {
            try {
                $maindir = $this->db_file;
                $main = new \SQLite3($maindir);
                if (!$main) {
                    echo 'code：' . $main->lastErrorCode();
                    echo 'Error：' . $main->lastErrorMsg();
                    $main->close();
                    die;
                }
                $result = $main->exec($sql);
                $main->close();
            } catch (\Exception $e) {
                if (isset($main)) {
                    $main->close();
                }
            }
            return $result;
        }
    }
    

// class Mysql {

//     public function __construct(){
//         $DB_HOST = 'localhost';
//         $DB_USER = 'root'; 
//         $DB_PASS = 'root';
//         $DB_NAME = 'photo_ctf';
//         $this->con=mysqli_connect($DB_HOST,$DB_USER,$DB_PASS,$DB_NAME); 
//         if (mysqli_connect_errno($this->con)) 
//         { 
//             echo "连接 MySQL 失败: " . mysqli_connect_error(); exit();
//         }

//     }

//     public function query($sql){
//         mysqli_query($this->con, $sql);
//         // mysqli_commit($con);
//         $id = mysqli_insert_id($this->con);
//         return $id;
//     }

//     public function select($sql){
//         $result=mysqli_query($this->con,$sql);
//         $data = $result -> fetch_all(MYSQLI_ASSOC);
//         return $data;
//     }

// }
    
class Photo {

	private $title, $path, $msyql;

	public function __construct($title, $path){
        $this -> title  = $title;
        $this -> path  = $path;
        $this -> mysql = new Mysql();
    }

    public function show(){
    	
    }

    public function exists(){
        return file_exists($this->path);
    }

    public function getPath(){
        return $this->path;
    }


}

class User {
	private $name, $age, $photos;

	public function __construct($name, $age){
        $this -> name  = $name;
        $this -> age  = $age;
    }

    public function uploadPhoto($photo){
        if(is_array($this->photos)){
            array_push($this->photos, $photo);
        }
        else{
            $this->photos = array($photo);
        }
    }

    public function __destruct(){
        # 检查异常，查看图片是否存在
        if(is_array($this->photos)){
            foreach($this->photos as $photo){
                if(! $photo->exists()){
                    $log = new Log();
                    Log::error("photo不存在,". $photo->getPath());
                }
            }
        }
    }

}

class Log {

    public function __construct(){
        $this->filename = date("Y-m-d", time()).".log";
        $this->handler = fopen("logs/" . $filename, 'a');
        $this->error = Error::record;
        $this->arg1 = Error::arg1;
        $this->arg2 = Error::arg2;
    }

    private function getIP(){
        return $_SERVER['REMOTE_ADDR'];
    }

    private function getTime(){
        return data("Y-m-d H:i:s", time());
    }

    public function error($msg){
        fwrite($handler, sprintf("%s:%s: %s\n", $this->getIP(), $this->getTime(), $msg));
    }

    public function __call($name, $arguments){
        printf("暂时还没有开放方法调用");
        call_user_func($this->error, $this->arg1, $this->arg2);
    }

    public function __destruct(){
        fclose($handler);
    }

}

class Error {
    private static $arg1 = "nothing";
    private static $arg2 = "nothing";
    public static function record(){
        echo "Recording...    ".$arg;
    }
}




