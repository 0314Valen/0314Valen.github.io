<?php

include_once "class.php";
header("Content-type:text/html;charset=utf-8");

if(!isset($_FILES['photo'])){
    exit('请正常上传文件');
}

function escape($str){
    $str = str_replace("'", "", $str);
    $str = str_replace("\"", "", $str);
    $str = str_replace("\\", "", $str);
    $str = str_replace("/", "", $str);
    return $str;
}

// 允许上传的图片后缀
$allowedExts = array("jpg", "png", "gif", "jpeg");

$temp       = explode(".", $_FILES["photo"]["name"]);
$extension  = end($temp);     
$name       = isset($_POST['name'])  ? escape($_POST['name']) : "未知";
$age        = isset($_POST['age'])   ? escape($_POST['age']) : "0";
$title      = isset($_POST['title']) ? escape($_POST['title']) : "未定义title";

if (($_FILES["photo"]["size"] < 204800) && in_array($extension, $allowedExts))
{
    if ($_FILES["photo"]["error"] > 0)
    {
        echo "<script>alert('上传失败，请重试');history.go(-1);</script>";exit;
    }
    else
    {
    	$new_filename = time().'.'.$extension;
        move_uploaded_file($_FILES["photo"]["tmp_name"], "./upload/" . $new_filename);
        echo "<script>alert('上传成功，"."./upload/" . $new_filename."');history.back();</script>";
        $sqlite = new Sqlite();
        $sqlite->query(sprintf("INSERT INTO photos(`title`, `path`, `name`, `age`, `time`) VALUES ('%s', '%s', '%s', '%s', '%s')", $title, "./upload/" . $new_filename, $name, $age, time() ));
        exit;
    }
}
else
{
    echo "<script>alert('只能上传jpg,png,gif,jpeg后缀的文件');history.go(-1);</script>";exit;
}
