<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>照片墙</title>
	<!-- 最新版本的 Bootstrap 核心 CSS 文件 -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">

	<!-- 可选的 Bootstrap 主题文件（一般不用引入） -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap-theme.min.css" integrity="sha384-6pzBo3FDv/PJ8r2KRkGHifhEocL+1X2rVCTTkUfGk7/0pbek5mMa1upzvWbrUbOZ" crossorigin="anonymous">

	<!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
	<style>
		body {
			padding-left: 10px;
		}
		.content {
			margin: 0 auto;
			width: 50%;
		}

	</style>
</head>
<body>
	<div class='content'>
		<h2>用照片来记录美好的瞬间</h2>
		<?php
			include_once "class.php";
			$sqlite = new Sqlite();
			$i = 0;
			echo "<table><tr>";
			foreach($sqlite->select("SELECT * FROM photos") as $res){
				if($i % 3 == 0 && $i != 0){
					echo "</tr><tr>";
				}
				$photo = sprintf("<td><img width='50' height='80' src='%s'><br><a href='show.php?path=%s'>%s</a><br>%s</td>", $res['path'], $res['path'], htmlspecialchars($res['title']), date("Y-m-d H:i:s", $res['time']));
				echo $photo;
				$i++;
			}
			echo "</tr>";
			echo "</table>";
		?>
		<hr>
		<form role="form" action="upload.php" method="POST" enctype="multipart/form-data">
		  <div class="form-group">
		    <label for="title">文件标题</label>
		    <input type="text" class="form-control" style="width: 50%;" name="title" id="title" placeholder="请输入标题">
		  </div>
		  <div class="form-group">
		    <label for="inputfile">上传文件</label>
		    <input type="file" id="inputfile" name="photo">
		    <p class="help-block">选择需要上传的照片文件</p>
		  </div>
		  <div class="form-group">
		    <label for="name">人名：</label>
		    <input type="text" class="form-control" style="width: 50%;" id="name" name="name" placeholder="请输入名字">
		  </div>
		  <div class="form-group">
		    <label for="age">年龄：</label>
		    <input type="number" class="form-control" style="width: 50%;" id="age" name="age" placeholder="请输入年龄" value="18">
		  </div>
		  <button type="submit" class="btn btn-default">提交</button>
		</form>
	</div>
	<!-- 为了防止文件丢失，小明喜欢对网站进行备份 -->
</body>
</html>