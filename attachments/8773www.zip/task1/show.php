<?php

include_once "class.php";
header("Content-type:image/png;charset=utf-8");

function startsWith($needle, $haystack) {
	return preg_match('/^' . preg_quote($needle, '/') . '/', $haystack);
}

function endsWith($needle, $haystack) {
	return preg_match('/' . preg_quote($needle, '/') . '$/', $haystack);
}

$path = isset($_GET['path']) ? strtolower($_GET['path']) : 'unknown';
if(startsWith('http', $path) || startsWith('ftp', $path) ){
	exit("bad path1");
}

if(!endsWith('jpg', $path) && !endsWith('jpeg', $path) && !endsWith('gif', $path) && !endsWith('png', $path) ){
	exit("bad path2");
}

if(file_exists($_GET['path'])){
	echo file_get_contents($_GET['path']);
}
else{
	echo 'file not found';
}