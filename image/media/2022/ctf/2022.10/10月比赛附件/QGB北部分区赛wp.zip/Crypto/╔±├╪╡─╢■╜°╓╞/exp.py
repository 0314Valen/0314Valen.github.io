import base64

# 二转十六
# 十六转字符串
# 替换s字符串。

s= '3EP/3VLJq1+Ssh3/7ljM2RmT5V7O4l3T6EDC8E7E2ESVqlrXqVS'
t = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
l=""
for i in s:
    l += t[(t.index(i)-30)%64]

if len(l)%4!=0:
    l=l+"="*(4-(len(l)%4))
print(l)

s = str(base64.b64decode(l),"utf-8")
print(s)

