#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define N 25
void change(char *a, int c){
    for(int i = 0; i < strlen(a); ++i){
        a[i] ^= c;
    }
}
int main(){
    char buf[N];
    char ans[N] = {105, 126, 108, 113, 121, 126, 127, 107, 121, 125, 123, 99, 98, 123, 109, 123, 120, 125, 107, 121, 110, 107, 121, 119};
    scanf("%24s", buf);
    change(buf, 10);
    if(memcmp(buf, ans, strlen(buf)) == 0){
        printf("OK!\n");
    }
    return 0;
}
