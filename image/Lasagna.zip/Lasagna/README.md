## Name

Lasagna

## Description

There's a sneaky hacker who stole an important sign from us, we traced it back to him but we don't have the proof. We got a partial images of his computer. We need your help to bring it to justice

Flag format:flag{*}

## Flag

flag{279f78a8-18ef-4336-ad15-aa2e1cf57c7b}

